# 🎯 INSTRUÇÕES DE USO - Questionário de Anamnese Capilar

## 📁 **ARQUIVOS NECESSÁRIOS**

Para o questionário funcionar corretamente, você precisa dos seguintes arquivos na mesma pasta:

### ✅ **Arquivos Obrigatórios:**
1. **`index.html`** - Arquivo principal do questionário
2. **`complete_hair_database.js`** - Base de dados com produtos e lógica de recomendação

### 📋 **Verificação Rápida:**
```
pasta-do-questionario/
├── index.html
└── complete_hair_database.js
```

---

## 🚀 **COMO USAR**

### **Método 1: Abrir Localmente**
1. Baixe ambos os arquivos (`index.html` e `complete_hair_database.js`)
2. Coloque-os na mesma pasta
3. Clique duas vezes no arquivo `index.html`
4. O questionário abrirá no seu navegador

### **Método 2: Servidor Local**
1. Coloque os arquivos em uma pasta do servidor web
2. Acesse via `http://localhost/pasta-do-questionario/`

---

## 🔧 **SOLUÇÃO DE PROBLEMAS**

### ❌ **Problema: "Função não encontrada"**
**Causa:** Arquivo `complete_hair_database.js` não foi carregado

**Soluções:**
1. ✅ Verifique se ambos os arquivos estão na mesma pasta
2. ✅ Verifique se o nome do arquivo está correto: `complete_hair_database.js`
3. ✅ Teste em outro navegador (Chrome, Firefox, Safari)
4. ✅ Se usando servidor, verifique permissões de arquivo

### ❌ **Problema: Resultados não aparecem**
**Causa:** JavaScript bloqueado ou erro de carregamento

**Soluções:**
1. ✅ Habilite JavaScript no navegador
2. ✅ Verifique o console do navegador (F12) para erros
3. ✅ Recarregue a página (Ctrl+F5)

---

## 🧪 **TESTE RÁPIDO**

Para verificar se está funcionando:

1. **Abra o questionário**
2. **Pressione F12** (Console do navegador)
3. **Digite no console:**
   ```javascript
   console.log(typeof determineDetailedHairType);
   console.log(typeof generateCompleteRecommendations);
   ```
4. **Resultado esperado:**
   ```
   function
   function
   ```

Se aparecer `undefined`, o arquivo JavaScript não foi carregado.

---

## 📱 **COMPATIBILIDADE**

### ✅ **Navegadores Suportados:**
- Chrome 80+
- Firefox 75+
- Safari 13+
- Edge 80+

### ✅ **Dispositivos:**
- Desktop (Windows, Mac, Linux)
- Tablets
- Smartphones

---

## 🎨 **FUNCIONALIDADES**

### 🌐 **Bilíngue:**
- Português (padrão)
- Inglês (clique no botão "English")

### 📊 **Análise Completa:**
- 8 perguntas detalhadas
- Determinação do tipo exato (1A-4C)
- Recomendações personalizadas

### 🛍️ **Recomendações:**
- Produtos específicos das marcas pesquisadas
- Rotina personalizada
- Marcas recomendadas
- Ingredientes ativos

---

## 📞 **SUPORTE**

Se ainda tiver problemas:

1. **Verifique** se ambos os arquivos estão presentes
2. **Teste** em navegador diferente
3. **Consulte** o console do navegador para erros específicos

**O questionário está 100% funcional quando os dois arquivos estão presentes!**

