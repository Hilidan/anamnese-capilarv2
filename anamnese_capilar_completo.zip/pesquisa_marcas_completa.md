# Informações sobre Tipos de Cabelo - Natura

## Classificação de Andre Walker (1 a 4, com subdivisões A, B, C)

### Tipo 1: Cabelos Lisos
- **1a:** Fino, leve, 




# Informações sobre Tipos de Cabelo - O Boticário

O Boticário também classifica os cabelos em:
- **Cabelo Liso:** Pouco ou nenhum volume, tende a ser mais oleoso na raiz.
- **Cabelo Ondulado:** Ondas suaves em “S”, pode variar de fino a grosso, exige cuidados para evitar frizz.
- **Cabelo Cacheado:** Formato espiral, naturalmente mais seco, necessita de hidratação intensa.
- **Cabelo Crespo:** Cachos bem definidos e volume exuberante, exige atenção especial à hidratação e nutrição, combatendo ressecamento e quebra.

## Linha Match. Science
- **Match. Science Crescimento:** Para estimular o crescimento saudável, combater a queda e fortalecer a fibra capilar (shampoo, máscara, tônico).
- **Match. Science Reconstrução:** Para cabelos danificados por química ou agressões externas, proporciona reparação profunda, devolvendo força, resistência e brilho (shampoo, condicionador, máscara, ampola).

## Cuidados Gerais Sugeridos:
- Limpeza: Escolher shampoo adequado ao tipo de cabelo.
- Hidratação: Máscaras de tratamento e condicionadores nutritivos.
- Reconstrução: Produtos com ação reconstrutora para fortalecer os fios.
- Proteção: Protetor térmico antes de usar secador ou chapinha.




# Informações sobre Tipos de Cabelo - Truss Professional

A Truss Professional oferece soluções para **todos os tipos de cabelo**, abordando tanto o formato dos fios (lisos, cacheados, crespos) quanto a condição de hidratação (secos, oleosos, normais) e a necessidade de restauração, tratamento e proteção.

## Principais Linhas e Tratamentos:
- **Infusion:** Hidratação intensa para cabelos secos e opacos, combate o ressecamento e estimula o brilho.
- **Nutri Infusion:** Nutrição profunda para cabelos desidratados, promovendo brilho, maciez e toque sedoso.
- **Uso Obrigatório:** Linha para reconstrução, hidratação e proteção contra danos, com produtos como spray e óleo reconstrutor.
- **Frizz Zero:** Solução para combater o frizz e proporcionar brilho intenso, toque aveludado e movimento.

A Truss enfatiza a alta qualidade e tecnologia de seus produtos, com intenso poder hidratante e nutritivo para recuperar e proteger os fios.




# Informações sobre Tipos de Cabelo - Forever Liss

A Forever Liss oferece produtos para **todos os tipos de cabelo** com foco em hidratação, nutrição e reconstrução capilar, combatendo problemas como frizz, emborrachamento, pontas duplas, queda, ressecamento e cabelos oleosos.

## Principais Linhas e Tratamentos:
- **Hidratação (Banho de Verniz, Cauter Restore, Catiônica, Blindagem Capilar Biomimética, Óleo de Argan e Olive Oil):** Para cabelos quebradiços e sem brilho, visam manter a umidade natural, melhorar a força e diminuir o aspecto poroso. Incluem ativos como óleo de coco, D pantenol, phytoqueratina, queratina, ácido lático e aminoácidos.
- **Cabelo Liso e Ondulado (Desmaia Cabelo, Xô Frizz, Maracujá e Malaleuca e Cresce Cabelo):** Foco no controle do frizz e oleosidade, mantendo o alinhamento e brilho dos fios.
- **Cabelos Crespos e Cacheados (Abacachos, Cachos e Crespo):** Necessitam de nutrição e umectação intensas devido à curvatura que facilita o ressecamento. Produtos com mix de óleos (abacate, argan, neem, amla) e ativos como biotina, D-panthenol, queratina e elastina para modelar e blindar os fios.

## Tratamentos Essenciais (Cronograma Capilar):
- **Hidratação:** Repõe a água e nutrientes, essencial para maciez e brilho.
- **Nutrição:** Repõe lipídios, fundamental para a força e saúde dos fios.
- **Reconstrução (Reparação):** Visa garantir um fio resistente, sem pontas duplas e porosidade, repondo massa capilar.




# Informações sobre Tipos de Cabelo e Tratamentos - Inoar

A Inoar oferece uma variedade de produtos e tratamentos capilares, focando em diferentes necessidades dos cabelos, ao invés de uma classificação específica de tipos de cabelo (como liso, ondulado, cacheado, crespo).

## Principais Tratamentos e Linhas:
- **Hidratação:** Produtos para repor a umidade dos fios, como ampolas de hidratação intensiva (ex: Argan Inoar, Absolut Daymoist Inoar).
- **Reconstrução:** Linhas para reconstruir a fibra capilar, como as ampolas de reconstrução (ex: Cicatrifios Inoar).
- **Anti-Frizz:** Produtos para controle do frizz.
- **Anti-Queda:** Linhas para combater a queda capilar.
- **Brilho e Proteção:** Produtos que promovem brilho e protegem os fios.
- **Cabelos Danificados:** Tratamentos específicos para cabelos que sofreram danos.
- **Leave-in:** Produtos sem enxágue para finalização e tratamento.
- **Óleos:** Óleos capilares para nutrição e brilho (ex: Óleo de Argan Inoar).
- **Creme de Pentear:** Para auxiliar no desembaraço e modelagem dos fios.
- **Gelatina e Mousses:** Para definição e volume, especialmente para cabelos cacheados e crespos.

A Inoar também possui linhas específicas para curvaturas, como a 'Meu Cacho Meu Crush', que indica produtos para cabelos cacheados e crespos (2A a 4C), focando em definição e hidratação para esses tipos de cabelo.




# Informações sobre Tipos de Cabelo e Tratamentos - Lola Cosmetics

A Lola Cosmetics oferece uma vasta gama de produtos para diversos tipos e necessidades capilares, com um foco em ingredientes ativos e formulações que atendem a demandas específicas. A marca não se limita a uma classificação rígida de tipos de cabelo, mas oferece soluções para:

## Tipos de Cabelo (com base nos filtros do site):
- **Cacheado**
- **Crespo**
- **Liso**
- **Ondulado**
- **Transição**

## Principais Linhas e Tratamentos (exemplos):
- **Morte Súbita:** Linha de tratamento intensivo para restaurar a barreira de hidratação natural dos cabelos, proporcionando suavidade, força e desembaraço.
- **Papo Reto:** Linha detox com shampoo e máscara de tratamento.
- **Purple Acid:** Linha para cabelos loiros, coloridos ou mechados, com foco em restauração e manutenção da cor.
- **Comigo Ninguém Pode:** Gama para cabelos pintados, com madeixas, ressecados e outros tipos.
- **Abacachos:** Produtos para cabelos cacheados e crespos, com foco em nutrição e umectação, utilizando óleos como o de abacate.

A Lola Cosmetics se destaca por suas formulações com ingredientes ativos que visam atender às necessidades específicas de cada tipo de cabelo e problema capilar, como frizz, danos, ressecamento, etc.




# Informações sobre Tipos de Cabelo e Tratamentos - Embelleze

A Embelleze oferece uma vasta gama de produtos para **todos os tipos de cabelo**, com foco em soluções para diversas necessidades capilares. A marca não se limita a uma classificação de tipos de cabelo (liso, ondulado, cacheado, crespo) de forma explícita em sua página de "tipos de cabelo", mas sim em necessidades e tratamentos.

## Necessidades e Tratamentos (com base nos filtros do site):
- **Antiqueda**
- **Hidratação**
- **Nutrição**
- **Reconstrução**
- **Cronograma Capilar**
- **Antifrizz**
- **Brilho**
- **Blindagem**

## Linhas e Produtos (exemplos):
- **Novex:** Uma das linhas mais conhecidas, com produtos para diversas necessidades, como hidratação, reconstrução, harmonização capilar, etc.
- **Natu Hair:** Linha que também oferece produtos para cronograma capilar.

A Embelleze foca em oferecer soluções completas para o cuidado capilar, com produtos que atendem desde a hidratação básica até tratamentos mais específicos para cabelos danificados, com queda, frizz, etc. A marca enfatiza a importância do cronograma capilar (hidratação, nutrição e reconstrução) como uma rotina essencial para a saúde dos fios.




# Informações sobre Tipos de Cabelo e Tratamentos - Sweet Hair

A Sweet Hair, através de seus produtos, oferece tratamentos para uma ampla gama de tipos e condições capilares, incluindo:

## Tipos de Cabelo e Condições Atendidas:
- **Cabelos danificados**
- **Cabelos lisos**
- **Cabelos cacheados**
- **Cabelos descoloridos**
- **Cabelos com frizz**
- **Cabelos secos**
- **Cabelos oleosos**
- **Cabelos com queda**

## Principais Tratamentos e Produtos:
- **Máscaras capilares, séruns, ampolas, fluídos:** Desenvolvidos para recuperar a saúde e beleza dos fios.
- **Tratamentos redutores de volume e alisamento:** Como a linha Lovely, que proporciona hidratação e efeito liso.
- **Tratamentos anti-aging:** Para regenerar fios danificados e prevenir o envelhecimento capilar.
- **Tratamento de Difusão capilar:** Para reestruturação interna e externa da fibra capilar.

A Sweet Hair enfatiza a importância de selecionar produtos com base no tipo de cabelo e suas necessidades específicas. A marca também sugere a adesão a um **cronograma capilar** para tratamentos mais intensos e eficazes.




# Informações sobre Tipos de Cabelo e Tratamentos - Apice Cosméticos

A Apice Cosméticos, anteriormente Apse Cosmetics, é especializada em produtos para as técnicas de No Poo e Low Poo, e tem um foco forte em cabelos cacheados e naturais. A marca oferece opções para diversos tipos e condições de cabelo:

## Tipos de Cabelo (com base nas categorias do site):
- **Cacheados**
- **Crespos**
- **Ondulados**
- **Lisos**
- **Transição Capilar**
- **Com Química**
- **Loiros, Mechas e Grisalhos**
- **Fracos e com quedas**

## Principais Linhas e Tratamentos:
- **Linha Cachos e Crespo Power:** Focada em cabelos cacheados e crespos, com produtos livres de sulfatos, parabenos e corantes, veganos e cruelty-free. Visam combater ressecamento, falta de definição e frizz.
- **Linha Scalp Care:** Para o cuidado do couro cabeludo, promovendo saúde da raiz às pontas.
- **Tratamentos de Hidratação, Nutrição, Reconstrução e Reparação:** A marca oferece produtos para essas necessidades essenciais do cabelo.

A Apice Cosméticos se destaca por suas fórmulas ricas em ativos naturais, buscando trazer o melhor tratamento para o cabelo sem causar danos ao meio ambiente. A marca também oferece um "Apice Quiz" para ajudar os usuários a identificar o tipo de cabelo e os produtos mais adequados.




# Informações sobre Tipos de Cabelo e Tratamentos - Olenka Cosméticos

A Olenka Cosméticos é uma marca que oferece soluções profissionais para salões de beleza, com produtos que atendem a diversas necessidades e tipos de cabelo. A marca categoriza seus produtos com base em:

## Tipos de Cabelo:
- **Brancos ou grisalhos**
- **Coloridos**
- **Lisos ou alisados**
- **Loiros**
- **Cacheados**

## Kits e Tratamentos:
- **Hidratação:** Para repor a umidade dos fios.
- **Nutrição:** Para nutrir e revitalizar os cabelos.
- **Pós Química:** Tratamentos específicos para cabelos que passaram por processos químicos.
- **Finalizadores:** Produtos para finalizar e proteger os cabelos.
- **Enzimoplastia (Alisamento Enzimático):** Um sistema de transformação capilar que busca um cabelo mais liso, natural e saudável.
- **Bio Reconstrutor:** Tratamento que atua como stop quebra imediato.
- **Linha Cachos (Secret Curl):** Inclui creme ativador modelador, gelatina ativadora e mousse nutritivo para cabelos cacheados.

A Olenka Cosméticos foca em tratamentos que proporcionam brilho, movimento e saúde aos cabelos, com destaque para a linha profissional e soluções para diferentes necessidades capilares.




## Compilado de Classificações e Tratamentos de Marcas Brasileiras

As marcas brasileiras de cosméticos capilares, como Natura, O Boticário, Truss Professional, Forever Liss, Inoar, Lola Cosmetics, Embelleze, Sweet Hair e Apice Cosméticos, embora utilizem diferentes abordagens em suas classificações e focos de tratamento, convergem em alguns pontos chave:

### Classificação de Tipos de Cabelo:

A maioria das marcas adota, de forma direta ou indireta, a classificação de curvatura dos fios (liso, ondulado, cacheado, crespo), muitas vezes com subdivisões para maior especificidade (como 1A, 1B, 1C para lisos, 2A, 2B, 2C para ondulados, etc.). Além da curvatura, a porosidade, espessura e oleosidade da raiz são fatores frequentemente considerados para a recomendação de produtos.

### Necessidades e Condições Capilares Comuns:

As marcas abordam uma vasta gama de necessidades e condições capilares, que incluem:
- **Hidratação:** Reposição de água e nutrientes essenciais para maciez e brilho. Produtos com óleos, pantenol, queratina e aminoácidos são comuns.
- **Nutrição:** Reposição de lipídios para combater o ressecamento, conferir brilho e vitalidade. Óleos vegetais (argan, coco, abacate) são ingredientes chave.
- **Reconstrução/Reparação:** Fortalecimento da fibra capilar, redução de quebra e pontas duplas, e recuperação de danos causados por processos químicos ou agressões externas. Queratina, proteínas e aminoácidos são frequentemente utilizados.
- **Controle de Frizz:** Produtos que alinham as cutículas capilares para reduzir o aspecto arrepiado.
- **Antiqueda:** Linhas e tratamentos para fortalecer o bulbo capilar e reduzir a queda dos fios.
- **Cabelos Quimicamente Tratados:** Produtos específicos para cabelos que passaram por alisamentos, colorações, descolorações, focando na recuperação e manutenção da saúde.
- **Cabelos Oleosos:** Soluções para controlar a oleosidade excessiva na raiz sem ressecar as pontas.
- **Cabelos Secos/Ressecados:** Foco em hidratação e nutrição intensivas.
- **Cabelos Loiros/Coloridos:** Produtos para manutenção da cor, evitar desbotamento e amarelamento.
- **Transição Capilar:** Linhas que auxiliam no processo de transição de cabelos quimicamente tratados para a textura natural.

### Cronograma Capilar:

O conceito de cronograma capilar (hidratação, nutrição e reconstrução) é amplamente difundido e incentivado por diversas marcas brasileiras como uma rotina essencial para a saúde e beleza dos fios, independentemente do tipo de cabelo.

### Ingredientes e Tecnologias:

As marcas utilizam uma variedade de ingredientes naturais (óleos vegetais, extratos de plantas) e tecnologias avançadas para desenvolver produtos eficazes. Há uma crescente preocupação com produtos veganos, cruelty-free e com formulações mais limpas.

Em resumo, as marcas brasileiras oferecem um leque abrangente de produtos e tratamentos que visam atender às necessidades específicas de cada tipo de cabelo e condição capilar, com um forte foco na saúde e beleza dos fios através de hidratação, nutrição e reconstrução.




# Informações sobre Tipos de Cabelo e Tratamentos - L'Oréal Professionnel

A L'Oréal Professionnel Paris oferece uma vasta gama de produtos e tratamentos capilares, focando em necessidades específicas do cabelo, que indiretamente se relacionam com os tipos de cabelo. As principais "Hair Needs" (necessidades capilares) abordadas são:

## Necessidades Capilares (Hair Needs):
- **Color radiance and maintenance:** Para cabelos coloridos, focando em brilho e manutenção da cor.
- **Deregulated scalps and hair loss:** Para problemas de couro cabeludo desregulado e queda de cabelo.
- **Anti-breakage and strength:** Para cabelos com quebra e que precisam de fortalecimento.
- **Curly hair for each type of curls and coils:** Para cabelos cacheados e crespos, com foco em diferentes tipos de curvatura.
- **Damaged hair and split ends:** Para cabelos danificados e com pontas duplas.
- **Thinned hair and lack of volume:** Para cabelos finos e com falta de volume.
- **Frizz control and smoothing:** Para controle do frizz e alisamento.

## Principais Linhas e Tratamentos (exemplos):
- **Scalp Advanced:** Linha para problemas de couro cabeludo, como desconforto e oleosidade.
- **Vitamino Color Spectrum:** Para cabelos coloridos, com shampoos neutralizantes (laranja, vermelho, amarelo) e máscaras para manutenção da cor e brilho.
- **Absolut Repair Molecular:** Tratamento de reparação molecular profunda para cabelos danificados, reconstruindo a estrutura capilar.
- **Inforcer:** Linha anti-quebra para redução imediata da quebra.
- **Metal Detox:** Previne a quebra do cabelo e a alteração da cor.
- **Curl Expression:** Linha dedicada a cabelos cacheados e crespos.

A L'Oréal Professionnel se posiciona como uma marca que oferece soluções profissionais e de alta tecnologia para diversas preocupações capilares, com produtos que vão desde a manutenção da cor até tratamentos moleculares para cabelos danificados.




# Informações sobre Tipos de Cabelo e Tratamentos - Kérastase (via Sephora)

A Kérastase, uma marca de luxo em cuidados capilares, oferece produtos e tratamentos focados em necessidades específicas do cabelo e do couro cabeludo. Embora não utilize a classificação de curvatura de Andre Walker diretamente em suas categorias principais, seus produtos são formulados para atender a uma ampla gama de tipos e preocupações:

## Tipos de Cabelo/Preocupações:
- **Dry & Damaged (Seco e Danificado):** Foco em hidratação profunda e reparação da fibra capilar.
- **Normal:** Para manutenção da saúde e beleza dos fios.
- **Thin (Fino):** Produtos para dar volume e densidade aos cabelos finos.
- **Color Care (Cabelo Colorido):** Para proteger a cor, prolongar a vivacidade e nutrir os fios coloridos.
- **Curly & Frizzy (Cacheado e com Frizz):** Para definição, hidratação e controle do frizz em cabelos cacheados e crespos.
- **Oily/Combination (Oleoso/Combinado):** Para controlar a oleosidade do couro cabeludo e equilibrar os fios.

## Tipos de Tratamento:
- **Hair Mask (Máscara Capilar):** Tratamentos intensivos para diversas necessidades (hidratação, nutrição, reparação).
- **Leave-in Conditioner (Condicionador Leave-in):** Produtos sem enxágue para proteção, hidratação e controle do frizz.
- **Hair Oil (Óleo Capilar):** Para brilho, nutrição e proteção térmica.
- **Hair Styling Products (Produtos para Pentear):** Para modelagem e finalização.
- **Scalp Treatments (Tratamentos para o Couro Cabeludo):** Para tratar problemas como oleosidade, coceira, queda e afinamento.
- **Hair Thinning & Hair Loss (Cabelo Fino e Queda de Cabelo):** Linhas específicas para fortalecer os fios e estimular o crescimento.
- **Hair Primers (Primers Capilares):** Produtos preparatórios para otimizar a absorção de outros tratamentos.

A Kérastase se destaca por sua abordagem diagnóstica, oferecendo soluções personalizadas para as necessidades individuais de cada cabelo, com foco em resultados profissionais e de alta performance.




# Classificação de Tipos de Cabelo - Wella (Sistema Andre Walker)

A Wella Professionals, em seu blog, detalha a classificação de tipos de cabelo, especialmente focada em cabelos ondulados, cacheados e crespos, utilizando o sistema de Andre Walker (1 a 4, com subdivisões A, B, C). Este sistema é uma ferramenta útil para entender como cuidar e estilizar o cabelo.

## O Sistema de Classificação:

- **Tipo 1: Cabelo Liso**
  - **1A:** Fino, macio, brilhante, sem curvatura.
  - **1B:** Liso com um pouco mais de corpo, mas ainda sem curvatura.
  - **1C:** Liso, mas com fios mais grossos e resistentes, podendo ter uma leve ondulação.

- **Tipo 2: Cabelo Ondulado**
  - **2A:** Ondas suaves e soltas, que podem ser facilmente alisadas ou cacheadas.
  - **2B:** Ondas mais definidas, que começam a formar um 




# Informações sobre Tipos de Cabelo e Tratamentos - Joico

A Joico se dedica a oferecer produtos de cuidado capilar que promovem a saúde e a beleza dos cabelos, com uma abordagem tecnológica e focada em resultados de salão. A marca categoriza seus produtos e tratamentos com base em diversas preocupações e tipos de cabelo:

## Preocupações e Tipos de Cabelo (Hair Concern/Hair Type):
- **Color Protection (Proteção da Cor):** Para cabelos coloridos, visando preservar a vivacidade da cor.
- **Curl Enhancing (Realce de Cachos):** Para cabelos cacheados e ondulados, buscando definição e hidratação.
- **Damaged (Danificado):** Para cabelos que precisam de reparo e reconstrução.
- **Dry Scalp (Couro Cabeludo Seco):** Para tratar o ressecamento do couro cabeludo.
- **Frizz-Free (Sem Frizz):** Para controlar o frizz e proporcionar maciez.
- **Heat Protection (Proteção Térmica):** Para proteger os fios do calor de ferramentas térmicas.
- **Oil Control (Controle de Oleosidade):** Para equilibrar a oleosidade do couro cabeludo.
- **Shine (Brilho):** Para aumentar o brilho dos cabelos.
- **Volume:** Para dar corpo e volume aos cabelos finos.
- **Blonde Hair Care (Cuidado para Cabelos Loiros):** Produtos específicos para loiras, incluindo neutralização de tons indesejados.
- **Breakage & Split Ends (Quebra e Pontas Duplas):** Para fortalecer os fios e prevenir a quebra.

## Principais Linhas e Tratamentos (exemplos):
- **Scalp Vitality:** Linha inspirada em skincare para a saúde do couro cabeludo.
- **Defy Damage:** Sistema de proteção para cor e saúde do cabelo, prevenindo desbotamento e danos.
- **K-PAK Color Therapy:** Para cabelos coloridos, focando na vivacidade da cor.
- **Moisture Recovery:** Para cabelos grossos/ásperos e secos, proporcionando hidratação intensa.
- **HydraSplash:** Para hidratação de 24 horas.
- **Blonde Life:** Para manter a cor e a saúde dos cabelos loiros.
- **Curls Like Us:** Linha para cabelos cacheados e ondulados, com óleos de Algas e Semente de Moringa, para definição e realce dos cachos.
- **JoiFull:** Para dar volume e corpo aos cabelos.

A Joico enfatiza a importância de escolher produtos que atendam às necessidades específicas de cada cabelo, oferecendo soluções abrangentes para diversos problemas capilares e tipos de fio.




# Classificação de Tipos de Cabelo - Sociedade Brasileira de Dermatologia (SBD)

A Sociedade Brasileira de Dermatologia (SBD) aborda a classificação dos cabelos com base em características genéticas e étnicas, que influenciam o padrão de crescimento, forma e textura dos fios. Esta perspectiva complementa as classificações baseadas na curvatura.

## Tipos de Cabelo por Etnia:

- **Cabelos Lisos:** Típicos de etnias mongólicas, orientais, esquimós e indígenas. Caracterizam-se por um formato mais cilíndrico e uma cutícula mais fechada, o que lhes confere brilho e menor tendência ao frizz.

- **Cabelos Ondulados:** Comuns em caucasianos, mas presentes em diversas etnias. Possuem um formato ovalado e apresentam ondas suaves ou mais definidas.

- **Cabelos Crespos:** Comuns na etnia negra. Possuem um formato elíptico e achatado helicoidal, o que resulta em um aspecto encaracolado e uma estrutura mais frágil, com maior tendência ao ressecamento devido à dificuldade da oleosidade natural do couro cabeludo em percorrer toda a extensão do fio.

## Características Adicionais:

A SBD ressalta que, além da curvatura, a genética e a etnia influenciam outras características importantes do cabelo, como:
- **Espessura:** Fios finos, médios ou grossos.
- **Densidade:** Quantidade de fios por centímetro quadrado.
- **Porosidade:** Capacidade do fio de absorver e reter umidade. Cabelos crespos, por exemplo, tendem a ser mais porosos.
- **Oleosidade:** Relacionada à produção de sebo pelas glândulas sebáceas do couro cabeludo, podendo resultar em cabelos normais, secos, oleosos ou mistos.

Compreender essas características é fundamental para a escolha de produtos e tratamentos adequados, visando a saúde e a beleza dos cabelos.

