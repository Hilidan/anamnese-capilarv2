# Demonstração dos Resultados do Questionário

## Exemplo de Análise: Cabelo Cacheado 3B

### Seu Perfil Capilar: **Cacheado 3B**

**Descrição:** Seus cabelos formam cachos em espiral bem definidos. Precisam de hidratação intensa e produtos específicos para definição e controle de volume.

---

## Rotina Recomendada

✦ Lavagem 2-3x por semana com shampoo adequado ao seu tipo
✦ Condicionador aplicado do meio às pontas após cada lavagem  
✦ Máscara de hidratação 2x por semana
✦ Leave-in específico para cachos/ondas aplicado em cabelo úmido
✦ Finalização com técnica de amassamento (scrunching)

---

## Produtos Específicos Recomendados

✦ **Shampoo:** Lola Cosmetics Eu Amo Meus Cachos, Truss Cachos Shampoo, Embelleze Novex Cachos
✦ **Condicionador:** Lola Cosmetics Eu Amo Meus Cachos Condicionador, Truss Cachos Condicionador, Forever Liss Cachos Condicionador
✦ **Tratamento:** Lola Cosmetics Máscara Cachos, Truss Cachos Máscara Nutritiva, Inoar Argan Oil Treatment
✦ **Finalização:** Lola Cosmetics Creme para Pentear Cachos, Truss Cachos Ativador, Embelleze Novex Cachos Creme

---

## Marcas Recomendadas

- **Lola Cosmetics** - Especialista em cabelos cacheados e crespos
- **Truss Professional** - Linha completa para cachos
- **Embelleze** - Produtos acessíveis e eficazes
- **Kérastase** - Linha premium internacional

---

*Esta análise foi baseada nas respostas do questionário e na pesquisa realizada sobre produtos de marcas brasileiras e internacionais.*

