# Métodos de Identificação Capilar

Com base na pesquisa realizada em diversas marcas de cosméticos brasileiras e internacionais, bem como em fontes de tricologia, é possível compilar os seguintes métodos e características para identificar o tipo de cabelo de uma pessoa:

## 1. Classificação pela Curvatura (Sistema Andre Walker e variações)

Este é o método mais amplamente utilizado e reconhecido, que categoriza o cabelo com base no padrão de ondulação/curvatura do fio. Geralmente, é dividido em 4 tipos principais, com 3 subtipos (A, B, C) para cada um, indicando a intensidade da curvatura.

### Tipo 1: Cabelos Lisos
- **Características:** Não possuem curvatura natural. Os fios caem retos da raiz às pontas.
- **Subtipos:**
  - **1A:** Liso extremo, fino e sedoso. Não segura cachos.
  - **1B:** Liso com um pouco mais de corpo, pode ter uma leve ondulação nas pontas. Segura cachos com dificuldade.
  - **1C:** Liso, mas mais grosso e resistente, com alguma ondulação perceptível. Pode ser mais difícil de alisar completamente.

### Tipo 2: Cabelos Ondulados
- **Características:** Possuem um padrão em forma de 


S (ou S-like) que varia de ondas soltas a ondas mais definidas.
- **Subtipos:**
  - **2A:** Ondas suaves e soltas, quase lisas na raiz e com leve curvatura nas pontas. Fáceis de alisar ou cachear.
  - **2B:** Ondas mais definidas, que começam a formar um S mais pronunciado a partir do meio do comprimento. Podem ter um pouco de frizz.
  - **2C:** Ondas bem definidas, próximas a cachos, com um S mais apertado e volume na raiz. Tendem a ter mais frizz.

### Tipo 3: Cabelos Cacheados
- **Características:** Formam cachos definidos em espiral, que podem variar de cachos soltos a cachos mais apertados.
- **Subtipos:**
  - **3A:** Cachos grandes e soltos, bem definidos, com cerca de 2 cm de diâmetro.
  - **3B:** Cachos mais apertados e definidos, com cerca de 1 cm de diâmetro. Mais volume e menos brilho que o 3A.
  - **3C:** Cachos muito apertados, pequenos e bem definidos, com cerca de 0,5 cm de diâmetro. Podem ter bastante volume e frizz.

### Tipo 4: Cabelos Crespos
- **Características:** Fios com um padrão de zigue-zague muito apertado ou em forma de mola, com alta contração. Tendem a ser mais frágeis e secos.
- **Subtipos:**
  - **4A:** Cachos pequenos e apertados, com um padrão de S bem definido, mas com a circunferência de uma agulha de crochê.
  - **4B:** Fios com um padrão de zigue-zague mais acentuado, sem um cacho definido, parecendo um Z. Podem encolher bastante.
  - **4C:** Fios com um padrão de zigue-zague muito apertado, sem definição de cacho visível. O tipo mais frágil e com maior encolhimento.

## 2. Classificação pela Espessura do Fio

A espessura do fio pode ser avaliada visualmente ou pelo toque:
- **Fino:** Quase imperceptível ao toque, difícil de sentir entre os dedos. Mais propenso a quebrar e embaraçar.
- **Médio:** Facilmente sentido entre os dedos, mas não é grosso. É o tipo mais comum.
- **Grosso:** Fio bem perceptível ao toque, robusto. Mais resistente, mas pode ser mais difícil de estilizar.

## 3. Classificação pela Oleosidade do Couro Cabeludo

A oleosidade do couro cabeludo influencia a necessidade de lavagem e os produtos a serem usados:
- **Normal:** Couro cabeludo equilibrado, sem excesso de oleosidade ou ressecamento. Os fios ficam limpos por 2-3 dias.
- **Seco:** Couro cabeludo com pouca produção de sebo, pode apresentar coceira e descamação. Os fios tendem a ser opacos e sem brilho.
- **Oleoso:** Couro cabeludo com produção excessiva de sebo, os fios ficam oleosos rapidamente (em menos de 24h). Pode causar caspa e queda.
- **Misto:** Raiz oleosa e pontas secas, comum em cabelos longos ou quimicamente tratados.

## 4. Classificação pela Porosidade do Fio

A porosidade refere-se à capacidade do cabelo de absorver e reter umidade. Pode ser testada com o 


teste do copo d'água:
- **Baixa Porosidade:** Fios que demoram a absorver água e flutuam na superfície. Cutículas muito fechadas. Dificuldade em absorver produtos.
- **Média Porosidade:** Fios que absorvem água em um tempo razoável e afundam lentamente. Cutículas levemente abertas. Ideal para absorção de produtos.
- **Alta Porosidade:** Fios que absorvem água rapidamente e afundam de imediato. Cutículas muito abertas, geralmente devido a danos. Facilidade em absorver produtos, mas dificuldade em reter a umidade.

## 5. Classificação pela Condição do Cabelo

Além do tipo natural, a condição atual do cabelo é crucial para a escolha de tratamentos:
- **Virgem:** Cabelo que nunca passou por processos químicos.
- **Quimicamente Tratado:** Cabelo que passou por coloração, descoloração, alisamento, permanente, etc. Requer cuidados específicos para reparar danos e manter a saúde.
- **Danificado:** Cabelo com quebra, pontas duplas, opacidade, ressecamento extremo, geralmente causado por processos químicos, calor excessivo ou falta de cuidados.
- **Saudável:** Cabelo com brilho, maciez, elasticidade e sem danos visíveis.

## 6. Teste de Elasticidade

O teste de elasticidade ajuda a determinar a saúde da fibra capilar:
- Pegue um fio de cabelo molhado e estique-o suavemente.
- **Cabelo Saudável:** Estica e volta ao normal sem quebrar.
- **Cabelo com Pouca Elasticidade:** Quebra facilmente ao esticar. Indica falta de hidratação ou nutrição.
- **Cabelo com Elasticidade Excessiva:** Estica muito e não volta ao normal, ficando elástico e emborrachado. Indica excesso de química ou falta de reconstrução.

## 7. Observação Visual e Tátil

A observação atenta e o toque são fundamentais:
- **Brilho:** Cabelos saudáveis tendem a ser mais brilhantes.
- **Maciez:** Cabelos macios ao toque indicam boa hidratação.
- **Textura:** Áspera ou porosa pode indicar danos ou alta porosidade.
- **Volume:** Naturalmente volumoso ou com tendência a ser mais "murcho".
- **Frizz:** Presença e intensidade do frizz.

Ao combinar a análise da curvatura, espessura, oleosidade, porosidade, condição e elasticidade, é possível ter um diagnóstico completo do tipo de cabelo e suas necessidades, permitindo a escolha de produtos e tratamentos mais eficazes.

